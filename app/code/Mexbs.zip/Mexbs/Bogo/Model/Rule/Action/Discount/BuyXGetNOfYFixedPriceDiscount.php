<?php
namespace Mexbs\Bogo\Model\Rule\Action\Discount;

class BuyXGetNOfYFixedPriceDiscount extends \Mexbs\ApBase\Model\Rule\Action\Discount\FixedPriceDiscountAbstract
{

}