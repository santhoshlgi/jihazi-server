<?php
namespace Mexbs\Bogo\Model\Rule\Action\Discount;

class BuyXGetNOfYPercentDiscount extends \Mexbs\ApBase\Model\Rule\Action\Discount\PercentDiscountAbstract
{

}