<?php
namespace Mexbs\Bogo\Model\Rule\Action\Discount;

class BuyXGetNOfYFixedDiscount extends \Mexbs\ApBase\Model\Rule\Action\Discount\FixedDiscountAbstract
{

}