<?php
namespace Mexbs\EachN\Model\Rule\Action\Discount;

class GetEachNAfterMFixedPriceDiscount extends \Mexbs\ApBase\Model\Rule\Action\Discount\FixedPriceDiscountAbstract
{

}