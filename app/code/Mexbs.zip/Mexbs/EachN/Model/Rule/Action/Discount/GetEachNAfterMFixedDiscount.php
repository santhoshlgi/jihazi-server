<?php
namespace Mexbs\EachN\Model\Rule\Action\Discount;

class GetEachNAfterMFixedDiscount extends \Mexbs\ApBase\Model\Rule\Action\Discount\FixedDiscountAbstract
{

}