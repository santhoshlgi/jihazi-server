<?php
namespace Mexbs\ApBase\Block\Product;

use \Magento\Framework\View\Element\Template;

class DisplayBannerBadge extends \Magento\Framework\View\Element\Template
{

}