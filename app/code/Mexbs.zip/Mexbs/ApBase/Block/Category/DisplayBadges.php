<?php
namespace Mexbs\ApBase\Block\Category;

use \Magento\Framework\View\Element\Template;

class DisplayBadges extends \Magento\Framework\View\Element\Template
{
}