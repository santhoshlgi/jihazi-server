<?php
namespace Mexbs\ApBase\Block;

class DisplayRulePopup extends \Magento\Framework\View\Element\Template
{}