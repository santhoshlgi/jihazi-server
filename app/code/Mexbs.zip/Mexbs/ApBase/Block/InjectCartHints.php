<?php
namespace Mexbs\ApBase\Block;

class InjectCartHints extends \Magento\Framework\View\Element\Template
{
}