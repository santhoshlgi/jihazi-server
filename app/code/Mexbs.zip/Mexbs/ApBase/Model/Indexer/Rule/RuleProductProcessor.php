<?php
namespace Mexbs\ApBase\Model\Indexer\Rule;

use Magento\Framework\Indexer\AbstractProcessor;

class RuleProductProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'apactionrule_rule';
}
