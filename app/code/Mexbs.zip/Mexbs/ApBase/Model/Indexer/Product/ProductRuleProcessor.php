<?php
namespace Mexbs\ApBase\Model\Indexer\Product;

use Magento\Framework\Indexer\AbstractProcessor;

class ProductRuleProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'apactionrule_product';
}
