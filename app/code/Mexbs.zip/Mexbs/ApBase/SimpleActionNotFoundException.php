<?php
namespace Mexbs\ApBase;

class SimpleActionNotFoundException extends \Exception
{

}