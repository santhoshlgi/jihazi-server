<?php
namespace Mexbs\ApBase\Logger;

class Logger extends \Monolog\Logger
{
}