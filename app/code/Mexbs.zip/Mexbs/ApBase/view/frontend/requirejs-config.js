var config = {
    map: {
        '*': {
            'Magento_SalesRule/js/view/cart/totals/discount':
                'Mexbs_ApBase/js/view/cart/totals/discount'
        }
    }
};