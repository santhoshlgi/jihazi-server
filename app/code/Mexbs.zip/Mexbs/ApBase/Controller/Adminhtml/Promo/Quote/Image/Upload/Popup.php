<?php
namespace Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload;

use Magento\Framework\Controller\ResultFactory;

class Popup extends \Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload
{
    protected function getImageId(){
        return 'popup_on_first_visit_image';
    }
}
