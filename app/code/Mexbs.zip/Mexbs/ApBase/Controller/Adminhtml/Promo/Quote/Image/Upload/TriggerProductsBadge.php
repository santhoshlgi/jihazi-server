<?php
namespace Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload;

use Magento\Framework\Controller\ResultFactory;

class TriggerProductsBadge extends \Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload
{
    protected function getImageId(){
        return 'badge_in_promo_trigger_products_image';
    }
}
