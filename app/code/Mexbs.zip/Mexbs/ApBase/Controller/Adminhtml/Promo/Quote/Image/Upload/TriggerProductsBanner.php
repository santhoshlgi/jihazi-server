<?php
namespace Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload;

use Magento\Framework\Controller\ResultFactory;

class TriggerProductsBanner extends \Mexbs\ApBase\Controller\Adminhtml\Promo\Quote\Image\Upload
{
    protected function getImageId(){
        return 'banner_in_promo_trigger_products_image';
    }
}
