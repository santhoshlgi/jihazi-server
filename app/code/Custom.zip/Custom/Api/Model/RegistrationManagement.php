<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Model;

class RegistrationManagement implements \Custom\Api\Api\RegistrationManagementInterface
{

    /**
     * {@inheritdoc}
     */
    public function registerDetails($firstname,$lastname,$email,$password,$phonenumber)
    {
        $res = 'https://smvatech.in/ecommerce/rest/V1/customers';
        $postRequest = array(
            'customer' => array(
                'email' => $email,
                'firstname' => $firstname,
                'lastname' => $lastname
            ),
            'password' => $password
        );
        
        $cURLConnection = curl_init($res);
        curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, json_encode($postRequest));
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
        $apiResponse = curl_exec($cURLConnection);
        $data = json_decode($apiResponse, true);
        curl_close($cURLConnection);
        // print_r($data);
        if(isset($data['id'])){
                $notif = array('SuccessCode'=> 200 , 'message' => "" , 'data' => array('userid' => $data['id'], 'first name' => $data['firstname'], 'last name' => $data['lastname'], 'email' => $data['email']));
        }else{
            $notif = array('SuccessCode'=> 400 , 'message' => "Customer Already Exist" , 'data' => "");
        }
        header("Content-Type: application/json; charset=utf-8");
        $ns = json_encode($notif);
        print_r($ns,false);
        die();
    }
}

