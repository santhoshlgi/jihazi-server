<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Model;

class LoginManagement implements \Custom\Api\Api\LoginManagementInterface
{

    /**
     * {@inheritdoc}
     */
    public function postLogin($email,$password,$os)
    {
        $res = 'https://smvatech.in/ecommerce/rest/V1/integration/customer/token';
        $postRequest = array(
            'username' => $email,
            'password' => $password
        );
        
        $cURLConnection = curl_init($res);
        curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
        
        $apiResponse = curl_exec($cURLConnection);
        $data = json_decode($apiResponse, true);
        curl_close($cURLConnection);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $CustomerModel = $objectManager->create('Magento\Customer\Model\Customer');
        $CustomerRepositoryInterface = $objectManager->create('Magento\Customer\Api\CustomerRepositoryInterface');
        $AddressRepositoryInterface = $objectManager->create('Magento\Customer\Api\AddressRepositoryInterface');

        $CustomerModel->setWebsiteId(1);
        $CustomerModel->loadByEmail($email);
        $userId = $CustomerModel->getId();

        
        if($userId){
            $customer = $CustomerRepositoryInterface->getById($userId);
            $billingAddressId = $customer->getDefaultBilling();
            $shippingAddressId = $customer->getDefaultShipping();

            $billingAddress = $AddressRepositoryInterface->getById($billingAddressId);
            $telephone = $billingAddress->getTelephone();
            if(!isset($data['message'])){
                $notif = array('SuccessCode'=> 200 , 'message' => "" ,'token' => $data,'os' => $os, 'data' => array('userid' => $userId, 'first name' => $CustomerModel->getFirstname(), 'last name' => $CustomerModel->getLastname(), 'email' => $email, 'phone' => $telephone));
            }else{
                $notif = array('SuccessCode'=> 400 , 'message' => "Invalid Password" , 'data' => "");  
            }
            
        }else{
            $notif = array('SuccessCode'=> 400 , 'message' => "Invalid Email" , 'data' => "");
        }
        header("Content-Type: application/json; charset=utf-8");
        $ns = json_encode($notif);
        print_r($ns,false);
        die();
    }
}

