<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Model;

class ResetManagement implements \Custom\Api\Api\ResetManagementInterface
{

    /**
     * {@inheritdoc}
     */
    public function resetPassword($userid,$password)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customer_check = $objectManager->get('Magento\Customer\Model\Customer');
        $customer_check->load($userid);
        
        if ( $customer_check->getId() ) {
        $customerRepositoryInterface = $objectManager->get('\Magento\Customer\Api\CustomerRepositoryInterface');
        $customerRegistry = $objectManager->get('\Magento\Customer\Model\CustomerRegistry');
        $encryptor = $objectManager->get('\Magento\Framework\Encryption\EncryptorInterface');
        $customer = $customerRepositoryInterface->getById($userid); // _customerRepositoryInterface is an instance of \Magento\Customer\Api\CustomerRepositoryInterface
        if($customer){
            $customerSecure = $customerRegistry->retrieveSecureData($userid); // _customerRegistry is an instance of \Magento\Customer\Model\CustomerRegistry
            $customerSecure->setRpToken(null);
            $customerSecure->setRpTokenCreatedAt(null);
            $customerSecure->setPasswordHash($encryptor->getHash($password, true)); // here _encryptor is an instance of \Magento\Framework\Encryption\EncryptorInterface
            $customerRepositoryInterface->save($customer);
            $notif = array('SuccessCode'=> 200 , 'message' => 'Your password reset successfully' , 'data' => '');
        }else{
            $notif = array('SuccessCode'=> 400 , 'message' => 'Your password reset Failure' , 'data' => '');
        }
        
        header("Content-Type: application/json; charset=utf-8");
        $ns = json_encode($notif);
        print_r($ns,false);
        die();
        }
    }
}

