<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Model;

class ForgetManagement implements \Custom\Api\Api\ForgetManagementInterface
{

    /**
     * {@inheritdoc}
     */
    public function forgetPassword($email,$phonenumber)
    {
        $res = 'https://smvatech.in/ecommerce/rest/V1/customers/password';
        // $data = array("a" => $a);
        $postRequest = array(
            'email' => $email,
            'template' => 'email_reset',
            'websiteId' => 1
        );
        $ch = curl_init($res);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postRequest));

        $response = curl_exec($ch);

        $data = json_decode($response, true);
        if($data == 1){
                $notif = array('SuccessCode'=> 200 , 'message' => "Please check email address for reset password link" , 'data' => "");
        }else{
            $notif = array('SuccessCode'=> 400 , 'message' => "Invalid user credentials" , 'data' => "");
        }
        
        header("Content-Type: application/json; charset=utf-8");
        $ns = json_encode($notif);
        print_r($ns,false);
        die();
    }
}

