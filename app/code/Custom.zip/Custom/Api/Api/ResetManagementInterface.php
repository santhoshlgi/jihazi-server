<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Api;

interface ResetManagementInterface
{

    /**
     * POST for Login api
     * @param int $userid
     *  @param string $password
     * @return string
     */
    
    public function resetPassword($userid,$password);
}

