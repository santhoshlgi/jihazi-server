<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Api;

interface RegistrationManagementInterface
{

    /**
     * POST for Login api
     * @param string $firstname
     * @param string $lastname
     * @param string $email
     *  @param string $password
     *  @param string $phonenumber
     * @return string
     */
    
    public function registerDetails($firstname,$lastname,$email,$password,$phonenumber);
}

