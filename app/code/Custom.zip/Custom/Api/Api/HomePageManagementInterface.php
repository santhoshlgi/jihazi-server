<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Custom\Api\Api;

interface HomePageManagementInterface
{

    /**
     * POST for Home Page api
     * @param string $identifier
     * @return string
     */
    
    public function homePageBanner($identifier);

    /**
     * POST for Home Page api
     * @param string $name
     * @return string
     */

    public function homePageSearch($name);

    /**
     * POST for Home Page api
     * @return string
     */

    public function homePageCategories();

    /**
     * POST for Home Page api
     *  @param string $token
     * @return string
     */

    public function homePageTopCategories($token);

    /**
     * POST for Home Page api
     * @return string
     */
    public function homePageProductBrand();
    /**
     * POST for Home Page api
     * @return string
     */
    public function homePageProductBrandOptions();
    
}

