let config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/select-payment-method': {
                'Mageprince_Paymentfee/js/action/payment/select-payment-method-mixin': true
            }
        }
    }
};
