var config = {
    map: {
        '*': {
            'Magento_Sales/order/create/form':'Mageprince_Paymentfee/order/create/form'
        }
    }
};
