/**
 * Aps_Fort Magento JS component
 *
 * @category    APS
 * @package     Aps_Fort
 */
/*browser:true*/
/*global define*/
define(
    [
        'ko',
        'jquery',
        'mage/translate'
    ],
    function (ko, $) {
        
    }
);