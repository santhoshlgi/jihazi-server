define(function () {
    'use strict';
    var extension = {
        isValid: function () {
            return true;
        }
    };
    return function () {
        return true;
    };
});